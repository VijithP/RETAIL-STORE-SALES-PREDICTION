namespace RetailStoreSalesPrediction.Models;

public class ProductCatalog
{
    public List<Product>? Products { get; set; }
}
