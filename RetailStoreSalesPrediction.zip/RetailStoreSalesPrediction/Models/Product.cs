namespace RetailStoreSalesPrediction.Models;

public class Product
{
    public int ProductId { get; set; }
    public string? Name { get; set; }
    public string? Description { get; set; }
    public string? Category { get; set; }
    public string? SKU { get; set; }
    public decimal Price { get; set; }
    public decimal CostPrice { get; set; }
    public decimal DiscountPercentage { get; set; }
    public int StockQuantity { get; set; }
    public int ReorderLevel { get; set; }
    public string? Supplier { get; set; }
    public DateTime ManufacturingDate { get; set; }
    public DateTime ExpiryDate { get; set; }
    public double Rating { get; set; }
    public int ReviewCount { get; set; }
    public string? Dimensions { get; set; }
    public decimal Weight { get; set; }
    public int WarrantyMonths { get; set; }
    public bool IsActive { get; set; }
    public DateTime CreatedDate { get; set; }
    public DateTime LastUpdatedDate { get; set; }
}
