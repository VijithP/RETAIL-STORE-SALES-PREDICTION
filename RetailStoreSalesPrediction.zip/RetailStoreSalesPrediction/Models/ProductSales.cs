namespace RetailStoreSalesPrediction.Models;

public class ProductSales
{
    public int SalesId { get; set; }
    public int ProductId { get; set; }
    public DateTime SalesDate { get; set; }
    public int SalesCount { get; set; }
    public int BalanceCount { get; set; }
    public decimal SalesAmount { get; set; }
    public decimal CostPrice { get; set; }
    public decimal Profit { get; set; }
    public string? StoreLocation { get; set; }
    public string? SalesStatus { get; set; }
}
