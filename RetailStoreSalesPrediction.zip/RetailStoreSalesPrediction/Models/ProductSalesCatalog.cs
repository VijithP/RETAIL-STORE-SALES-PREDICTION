namespace RetailStoreSalesPrediction.Models
{
    public class ProductSalesCatalog
    {
        public List<ProductSales> Sales { get; set; } = new List<ProductSales>();
    }
}
