using Microsoft.AspNetCore.Mvc;
using RetailStoreSalesPrediction.Models;
using System.Text.Json;

namespace RetailStoreSalesPrediction.Controllers
{
    public class ProductSalesController : Controller
    {
        private readonly ILogger<ProductSalesController> _logger;

        public ProductSalesController(ILogger<ProductSalesController> logger)
        {
            _logger = logger;
        }

        // GET: ProductSales
        public IActionResult Index()
        {
            try
            {
                var sales = LoadSalesData();
                return View(sales.OrderByDescending(s => s.SalesDate).ToList());
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error loading sales data");
                return View(new List<ProductSales>());
            }
        }

        // GET: ProductSales/GroupedByMonth
        public IActionResult GroupedByMonth()
        {
            try
            {
                var sales = LoadSalesData();
                var products = LoadProductData();
                var productDict = products.ToDictionary(p => p.ProductId, p => p.Name ?? "Unknown");
                
                // Group by product first, then show monthwise total salescount for each product
                var groupedByProduct = sales
                    .GroupBy(s => s.ProductId)
                    .OrderByDescending(g => g.Sum(s => s.SalesCount))
                    .Select(productGroup => new
                    {
                        ProductId = productGroup.Key,
                        ProductName = productDict.ContainsKey(productGroup.Key) ? productDict[productGroup.Key] : "Unknown",
                        TotalSalesCount = productGroup.Sum(s => s.SalesCount),
                        TotalSalesAmount = productGroup.Sum(s => s.SalesAmount),
                        TotalProfit = productGroup.Sum(s => s.Profit),
                        MonthlySalesCount = productGroup
                            .GroupBy(s => new { s.SalesDate.Year, Month = s.SalesDate.Month })
                            .OrderByDescending(m => m.Key.Year)
                            .ThenByDescending(m => m.Key.Month)
                            .Select(monthGroup => new
                            {
                                YearMonth = new DateTime(monthGroup.Key.Year, monthGroup.Key.Month, 1),
                                MonthName = new DateTime(monthGroup.Key.Year, monthGroup.Key.Month, 1).ToString("MMMM yyyy"),
                                SalesCount = monthGroup.Sum(s => s.SalesCount),
                                SalesAmount = monthGroup.Sum(s => s.SalesAmount),
                                Profit = monthGroup.Sum(s => s.Profit),
                                TransactionCount = monthGroup.Count()
                            })
                            .ToList()
                    })
                    .Cast<dynamic>()
                    .ToList();

                return View(groupedByProduct);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error loading grouped sales data");
                return View(new List<dynamic>());
            }
        }

        // API: Get all sales as JSON
        [HttpGet]
        public IActionResult GetAllSalesJson()
        {
            try
            {
                var sales = LoadSalesData();
                return Ok(sales.OrderByDescending(s => s.SalesDate));
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error loading sales JSON");
                return BadRequest(ex.Message);
            }
        }

        // API: Get sales by product ID
        [HttpGet]
        public IActionResult GetSalesByProduct(int productId)
        {
            try
            {
                var sales = LoadSalesData();
                var productSales = sales.Where(s => s.ProductId == productId).OrderByDescending(s => s.SalesDate);
                return Ok(productSales);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error loading sales for product {ProductId}", productId);
                return BadRequest(ex.Message);
            }
        }

        // API: Get sales by date range
        [HttpGet]
        public IActionResult GetSalesByDateRange(DateTime startDate, DateTime endDate)
        {
            try
            {
                var sales = LoadSalesData();
                var rangedSales = sales
                    .Where(s => s.SalesDate >= startDate && s.SalesDate <= endDate)
                    .OrderByDescending(s => s.SalesDate);
                return Ok(rangedSales);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error loading sales for date range");
                return BadRequest(ex.Message);
            }
        }

        // API: Get sales by store location
        [HttpGet]
        public IActionResult GetSalesByStore(string storeLocation)
        {
            try
            {
                var sales = LoadSalesData();
                var storeSales = sales
                    .Where(s => s.StoreLocation.Equals(storeLocation, StringComparison.OrdinalIgnoreCase))
                    .OrderByDescending(s => s.SalesDate);
                return Ok(storeSales);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error loading sales for store {StoreLocation}", storeLocation);
                return BadRequest(ex.Message);
            }
        }

        private List<ProductSales> LoadSalesData()
        {
            var filePath = Path.Combine(Directory.GetCurrentDirectory(), "Data", "productsales.json");
            var json = System.IO.File.ReadAllText(filePath);
            var options = new JsonSerializerOptions
            {
                PropertyNameCaseInsensitive = true
            };
            
            var salesCatalog = JsonSerializer.Deserialize<ProductSalesCatalog>(json, options);
            return salesCatalog?.Sales ?? new List<ProductSales>();
        }

        // GET: ProductSales/GroupedByMonthGraph
        public IActionResult GroupedByMonthGraph()
        {
            try
            {
                var sales = LoadSalesData();
                var products = LoadProductData();
                var productDict = products.ToDictionary(p => p.ProductId, p => p.Name ?? "Unknown");

                var groupedByProduct = sales
                    .GroupBy(s => s.ProductId)
                    .OrderByDescending(g => g.Sum(s => s.SalesCount))
                    .Select(productGroup => new
                    {
                        ProductId = productGroup.Key,
                        ProductName = productDict.ContainsKey(productGroup.Key) ? productDict[productGroup.Key] : "Unknown",
                        MonthlySalesCount = productGroup
                            .GroupBy(s => new { s.SalesDate.Year, Month = s.SalesDate.Month })
                            .Select(monthGroup => new
                            {
                                YearMonth = new DateTime(monthGroup.Key.Year, monthGroup.Key.Month, 1),
                                MonthName = new DateTime(monthGroup.Key.Year, monthGroup.Key.Month, 1).ToString("MMMM yyyy"),
                                SalesCount = monthGroup.Sum(s => s.SalesCount)
                            })
                            .ToList()
                    })
                    .Cast<dynamic>()
                    .ToList();

                // Build global ordered month list across all products
                var allMonths = groupedByProduct
                    .SelectMany(p => ((IEnumerable<dynamic>)p.MonthlySalesCount).Select(m => (DateTime)m.YearMonth))
                    .Distinct()
                    .OrderBy(d => d)
                    .ToList();

                var labels = allMonths.Select(d => d.ToString("MMMM yyyy")).ToList();

                // Prepare datasets for Chart.js
                var palette = new[] { "#0d6efd", "#f97316", "#10b981", "#6f42c1", "#d63384", "#198754", "#0dcaf0", "#fd7e14" };
                var datasets = new List<object>();
                int colorIdx = 0;

                foreach (var product in groupedByProduct)
                {
                    var data = new List<int>();
                    foreach (var month in allMonths)
                    {
                        var entry = ((IEnumerable<dynamic>)product.MonthlySalesCount).FirstOrDefault(m => ((DateTime)m.YearMonth) == month);
                        data.Add(entry != null ? (int)entry.SalesCount : 0);
                    }

                    datasets.Add(new
                    {
                        label = product.ProductName,
                        data = data,
                        backgroundColor = palette[colorIdx % palette.Length],
                        borderColor = "#ffffff",
                        borderWidth = 1
                    });

                    colorIdx++;
                    if (colorIdx >= 8) colorIdx = 0;
                }

                var viewModel = new
                {
                    Labels = labels,
                    Datasets = datasets
                };

                return View(viewModel);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error building grouped sales graph data");
                return View(new { Labels = new List<string>(), Datasets = new List<object>() });
            }
        }

        private List<Product> LoadProductData()
        {
            try
            {
                var filePath = Path.Combine(Directory.GetCurrentDirectory(), "Data", "products.json");
                var json = System.IO.File.ReadAllText(filePath);
                var options = new JsonSerializerOptions
                {
                    PropertyNameCaseInsensitive = true
                };
                
                var productCatalog = JsonSerializer.Deserialize<ProductCatalog>(json, options);
                return productCatalog?.Products ?? new List<Product>();
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error loading product data");
                return new List<Product>();
            }
        }
    }
}
