using System.Text.Json;
using Microsoft.AspNetCore.Mvc;
using RetailStoreSalesPrediction.Models;
namespace RetailStoreSalesPrediction.Controllers;

public class ProductController : Controller
{
    private readonly ILogger<ProductController> _logger;
    private readonly string _productsPath;

    public ProductController(ILogger<ProductController> logger)
    {
        _logger = logger;
        _productsPath = Path.Combine(Directory.GetCurrentDirectory(), "Data", "products.json");
    }

    private ProductCatalog? LoadProducts()
    {
        try
        {
            var json = System.IO.File.ReadAllText(_productsPath);
            var options = new JsonSerializerOptions { PropertyNameCaseInsensitive = true };
            return JsonSerializer.Deserialize<ProductCatalog>(json, options);
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Error loading products from JSON");
            return null;
        }
    }

    public IActionResult Index()
    {
        var catalog = LoadProducts();
        if (catalog?.Products == null)
        {
            _logger.LogWarning("No products found");
            return NotFound();
        }

        return View(catalog.Products);
    }

    public IActionResult Details(int id)
    {
        var catalog = LoadProducts();
        if (catalog?.Products == null)
        {
            return NotFound();
        }

        var product = catalog.Products.FirstOrDefault(p => p.ProductId == id);
        if (product == null)
        {
            _logger.LogWarning($"Product with ID {id} not found");
            return NotFound();
        }

        return View(product);
    }

    public IActionResult GetAllProductsJson()
    {
        var catalog = LoadProducts();
        if (catalog?.Products == null)
        {
            return NotFound(new { message = "No products found" });
        }

        return Json(catalog.Products);
    }

    public IActionResult GetProductJson(int id)
    {
        var catalog = LoadProducts();
        if (catalog?.Products == null)
        {
            return NotFound(new { message = "No products found" });
        }

        var product = catalog.Products.FirstOrDefault(p => p.ProductId == id);
        if (product == null)
        {
            return NotFound(new { message = $"Product with ID {id} not found" });
        }

        return Json(product);
    }

    public IActionResult GetByCategory(string category)
    {
        var catalog = LoadProducts();
        if (catalog?.Products == null)
        {
            return NotFound(new { message = "No products found" });
        }

        var products = catalog.Products
            .Where(p => p.Category != null && p.Category.Equals(category, StringComparison.OrdinalIgnoreCase))
            .ToList();

        if (products.Count == 0)
        {
            return NotFound(new { message = $"No products found for category '{category}'" });
        }

        return Json(products);
    }
}
