# AI Agent Instructions: Retail Store Sales Prediction

## Project Overview
ASP.NET Core 9.0 web application for retail store sales analysis and prediction. Uses MVC architecture with controller-based request handling and JSON-based product data. The project targets predictive analytics on retail inventory and sales patterns.

**Key Details:**
- Framework: ASP.NET Core 9.0 (net9.0)
- Pattern: MVC with Controllers, Views, Models
- Data: JSON-based product catalog in `Data/products.json`
- Nullable reference types enabled (`<Nullable>enable</Nullable>`)
- Implicit usings enabled for cleaner imports

## Architecture & Data Flow

### Project Structure
```
Controllers/      → HTTP request handlers (HomeController follows ASP.NET conventions)
Views/           → Razor templates (.cshtml files with Bootstrap styling)
Models/          → DTOs and view models (ErrorViewModel, future prediction models)
Data/            → JSON data sources (products.json with product catalog)
wwwroot/         → Static assets (CSS, JS, Bootstrap libraries)
```

### Application Pipeline
1. **Entry Point**: `Program.cs` sets up minimal hosting API
2. **Service Registration**: Controllers and static asset endpoints configured
3. **Middleware Stack**: HTTPS redirect → routing → controllers → static assets
4. **Routing**: Default route pattern `{controller=Home}/{action=Index}/{id?}`
5. **Data Layer**: Products loaded from `Data/products.json` as JSON source

### Product Data Model
Located in `Data/products.json`. Structure:
```json
{
  "products": [
    { "productId": 1, "name": "...", "category": "...", "price": ... }
  ]
}
```
Categories include: Electronics, Home & Kitchen, Stationery. This structure should be mirrored in C# models when implementing prediction features.

## Development Workflows

### Build & Run
```powershell
dotnet build              # Compile project (net9.0 target)
dotnet run               # Run with IIS Express (https://localhost:7094)
```

### Key Ports
- HTTP: `localhost:5283`
- HTTPS: `localhost:7094`
- Launch settings defined in `Properties/launchSettings.json` with auto-browser launch

### Adding Features
1. **New Models**: Add to `Models/` folder following ErrorViewModel pattern (nullable properties, POCOs)
2. **New Controllers**: Place in `Controllers/` with DI-injected ILogger
3. **New Views**: Add to `Views/{ControllerName}/` as `.cshtml` Razor templates
4. **Static Assets**: Place CSS/JS in `wwwroot/`, auto-served via `MapStaticAssets()`

## Conventions & Patterns

### Naming
- Controllers: `{Feature}Controller` (e.g., `HomeController`)
- Models: Pascal case, plural collections (e.g., `products` array in JSON)
- Views: Match controller action names (e.g., `Index.cshtml` for `Index()` action)
- Namespaces: Reflect folder structure (e.g., `RetailStoreSalesPrediction.Controllers`)

### Dependency Injection
- Constructor-injected `ILogger<T>` pattern used in HomeController
- Extend this for future services (e.g., `IProductService`, `IPredictionService`)
- Services configured in `Program.cs` via `builder.Services`

### Error Handling
- Default error view: `Views/Shared/Error.cshtml`
- ErrorViewModel captures request ID for tracking
- Environment-dependent error responses (HSTS in production)

### Static Content
- Bootstrap and jQuery included in `wwwroot/lib/`
- CSS: `wwwroot/css/site.css`
- JS: `wwwroot/js/site.js`
- Scoped CSS bundles auto-generated in `obj/Debug/net9.0/scopedcss/`

## Configuration & Environment

### Settings Files
- `appsettings.json`: Shared config (logging, CORS rules)
- `appsettings.Development.json`: Dev-specific overrides
- Structure: Logging levels default to "Information"; ASP.NET Core warnings suppressed

### Launch Profiles
Two profiles in `launchSettings.json`:
- **http**: Port 5283, environment=Development
- **https**: Port 7094 (primary), environment=Development

Both auto-launch browser on run.

## Implementation Priorities for Sales Prediction

When adding prediction features:
1. **Create models** (e.g., `SalesData`, `PredictionResult`) in `Models/` folder
2. **Load product data** from `Data/products.json` via file I/O or JSON deserialization
3. **Build prediction controller** with actions returning predictions as JSON or views
4. **Add views** for visualization (e.g., charts, predictions table)
5. **Register services** in `Program.cs` before `app.Build()`

## Key Files Reference
- [Program.cs](Program.cs) — Application startup and middleware configuration
- [Controllers/HomeController.cs](Controllers/HomeController.cs) — Request handling template
- [Data/products.json](Data/products.json) — Product catalog and data source
- [Models/](Models/) — Domain and view models (extend as needed)
- [Properties/launchSettings.json](Properties/launchSettings.json) — Run configurations
